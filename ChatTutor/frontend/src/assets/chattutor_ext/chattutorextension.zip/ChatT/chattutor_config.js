
const script = document.createElement('script');
script.type = 'module';
script.src = chrome.runtime.getURL('content_script.js');
document.head.appendChild(script);

chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    console.log('message: ', JSON.stringify(message))
    // Check if the message is to send data
    if (message.action === 'send_data') {
        // Store the data in local storage
        // localStorage.setItem('data_from_example_com', message.data);
        console.log('data: ', message.data)
    }
});