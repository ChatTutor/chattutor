const testmode = false
const BASE_URL = testmode ? "http://localhost:5000" : "https://beta-chattutor-nbqjgewnea-uc.a.run.app"

async function get_collection_from_url() {
    console.log("try Get course from url");
    // if (localStorage.getItem('collection') !== undefined && localStorage.getItem('collection') != null) {
    //     return true
    // }

    console.log("Get course from url");
    const __url = window.location.href
    const url2 = __url.split('?chattutor_sid')
    const url = url2[0]
    console.log(';;', url2)
    let res = await fetch(BASE_URL + '/prep/course/bymainpage', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({mainpage: url})
    })

    let collection = await res.json()
    console.log('text:',collection)

    if(collection['message'] !== 'success') {
        return [false, 'change_col']
    }

    let ret_v = ''
    if(collection['collection'] !== localStorage.getItem('collection')) {
        ret_v = 'change_col'
    }

    localStorage.setItem('collection', collection['collection'])
    if(collection['collection'] === 'null') {
        return [false, ret_v]
    }
    return [true, ret_v]
}

async function get_parameters_from_url() {
    const url = window.location.href
    const url2 = url.split('?chattutor_sid_')
    if (url2.length >= 2) {
        const key = url2[1]

        // make request for account:
        const res = await fetch(BASE_URL + '/prep/accescodes/getuseridandemail', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({code: key})
        })

        let username_and_email = await res.json()
        if(username_and_email['message'] !== 'success') {
            console.log('error: ', username_and_email)
            return undefined
        }
        localStorage.setItem('user_id', username_and_email['id'])
        localStorage.setItem('user_email', username_and_email['email'])
        localStorage.setItem('key', key)
        window.location.href = url2[0]
        return username_and_email
    } else {
        if(localStorage.getItem('key')) {
            // TODO: to check authenticity
            // TODO: also set in sessionStorage instead of localStorage
            return {message: 'success', id: localStorage.getItem('user_id'), email: localStorage.getItem('user_email')}
        }
    }
}

get_collection_from_url().then(async (a) => {
    if(a[0] !== true) {
        console.log("could not get collection!!")
        return
    }

    if(a[1] === 'change_col') {
        if(localStorage.getItem('key') !== undefined && localStorage.getItem('key') !== null) {
            if(localStorage.getItem('user_id') !== undefined && localStorage.getItem('user_id') !== null) {
                const testmode = false
                const BASE_URL = testmode ? "http://localhost:5000" : "https://beta-chattutor-nbqjgewnea-uc.a.run.app"
                const res = await fetch(BASE_URL + '/prep/accescodes/delete_key', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({code: localStorage.getItem('key'), user_id: localStorage.getItem('user_id')})
                })

            }
        }

        localStorage.removeItem('key')
        localStorage.removeItem('user_email')
        localStorage.removeItem('user_id')
    }

    const user = await get_parameters_from_url()
    if (user === undefined) {
        console.log("False key. user could not be found")
    }

    console.log('user: ', user)

    let EMBEDDING_COLLECTION_NAME = localStorage.getItem('collection');
    console.log('collection is ', EMBEDDING_COLLECTION_NAME)
    if(EMBEDDING_COLLECTION_NAME === null || EMBEDDING_COLLECTION_NAME === 'null') {
        return
    }
    const COURSE_URL = window.location.protocol + "//" + window.location.host
    const ADD_MESSAGES_TO_DB = true

// change testmode to false
// you have 2 more testmode variables change them to false too
// TODO: change url to beta-main
    const testmode = false
    const BASE_URL = testmode ? "http://localhost:5000" : "https://beta-chattutor-nbqjgewnea-uc.a.run.app"

    var global_movex = 0;
    var global_movey = 0;
    var should_move = true

    var validate_and_set = null

    var screen_width = 0;
    var screen_height = 0;

    var phone_width = 578
    screen_width = window.innerWidth
    screen_height = window.innerHeight
    window.addEventListener('resize', () => {
        screen_width = window.innerWidth
        screen_height = window.innerHeight
    })


    function setupEmbedMode_URL() {
        var reader = new FileReader();
        const charttutor_embed_elemment_andu = document.createElement("div")
        charttutor_embed_elemment_andu.setAttribute("style", "position: fixed; z-index: 2147483646;")
        charttutor_embed_elemment_andu.innerHTML = `<div class="allchattutor" id="move-andu">${chattutor_embed}</div>`
        document.body.append(charttutor_embed_elemment_andu)
        const container = document.getElementById("move-andu");
        const ini = document.getElementById("initiali");
        const movecontainer = document.getElementById("moveidallchattutor");
        const movecontainer2 = document.getElementById("msgInputDiv");

        const MARG = 10;

        function validateAndSet() {

            movecontainer.style.transition = "none"
            movecontainer.style.animation = "none"
            movecontainer.style.scale = "unset"
            if (screen_width > phone_width) {
                var box_ = ini.getBoundingClientRect()
                var box = {width: box_.width, height: box_.height, x: box_.x + 10, y: box_.y}
                let x_start = box.x + global_movex
                let y_start = box.y + global_movey


                x_start = x_start > MARG ? x_start : MARG;
                y_start = y_start > MARG ? y_start : MARG;

                if (x_start + box.width > window.innerWidth - MARG) {
                    x_start = window.innerWidth - MARG - box.width
                }

                if (y_start + box.height > window.innerHeight - MARG) {
                    y_start = window.innerHeight - MARG - box.height;
                }


                global_movex = x_start - box.x
                global_movey = y_start - box.y

                movecontainer.style.transform = `translate(${global_movex}px, ${global_movey}px)`;
            } else {
                ini.style.padding = '0';
                ini.style.margin = '10';
                movecontainer.style.transform = `translate(0, 0)`;
            }
        }

        validate_and_set = validateAndSet;

        function onMouseDrag(e) {
            if (!should_move) {
                return
            }
            e.preventDefault()
            const movementX = e.movementX
            const movementY = e.movementY
            // var box = movecontainer.getBoundingClientRect();
            // console.log(box)

            global_movex += movementX;
            global_movey += movementY;
            movecontainer.style.transition = "none"
            movecontainer.style.animation = "none"
            movecontainer.style.scale = "unset"
            validateAndSet()

        }

        window.addEventListener('resize', () => {
            movecontainer.style.transition = "none"
            movecontainer.style.animation = "none"
            movecontainer.style.scale = "unset"
            validateAndSet()
        })

        container.addEventListener("mousedown", () => {
            document.addEventListener("mousemove", onMouseDrag);
        });

        document.addEventListener("mouseup", () => {
            document.removeEventListener("mousemove", onMouseDrag);
            movecontainer.style.transition = "all 0.2s ease"
            // movecontainer2.style.transition = "all 0.2s ease"
        });

        movecontainer2.addEventListener('mouseenter', () => {
            should_move = false
        })

        movecontainer2.addEventListener('mouseleave', () => {
            should_move = true
        })

        original_file = COURSE_URL + window.location.pathname
        original_file = original_file.replaceAll(/[^A-Za-z0-9\-_]/g, '_')
        console.log(original_file)
        // get riginal file
        // original file = ....
    }

    let chattutor_embed = `
<div class="embed" id="initiali">
	<div>
        <link rel="stylesheet" href="content_styles.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

		<meta name="viewport" content="initial-scale=1, width=device-width">
    <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
</script>
	</div>
    <div>
</div>

    <div class="embed-chattutor-window" id="moveidallchattutor">
<!--        <div class="notification-of-login">-->
<!--        </div>-->

        <div class="scp-error" id="scpError">
                <span>This site appears to have SCP enabled. Please add ${BASE_URL} to the connection list. If you are not the maintainer, contact a maintainer</span>
        </div>
        
        <div class="login-error" id="loginError">
                <span>You are not logged in. Please login to talk to ChatTutor.</span>
        </div>
        
        
		<section class="msger">
            <div class="msg-header-helper">
                <header class="msger-header" id="idallchattutor">

                  <div class="msger-header-title">
                  <div style="display: flex; flex-direction: row">
                      <button class="close-embed"></button>
                      <button class="theme-button" id="themeBtn"></button>
                      </div>
                        <span style="padding-left: 5px" class="chattutor-b">ChatTutor</span>
                        ${user === undefined ? `<a href=${"\"" + BASE_URL + '/student/login/' + localStorage.getItem('collection') + "\""}>Login</a>` : `<span class="chattutor-b">${user["email"]}</span>`}
  
<!--                       <span id="addUrl">Add URL</span>-->
                       
                      
                  </div>
<!--                  <div class="msger-header-options">-->
<!--                    <span><i class="fas fa-cog"></i></span>-->
<!--                  </div>-->


                        
                        


                </header>
            </div>

            <main class="msger-chat">

                <div class="msg left-msg" style="margin-top: 50px !important;">
                    <div class="msg-bgd">
                        <div
                        class="msg-img"
                        id="msgImg"
                        style="background-image: url(https://static.thenounproject.com/png/2216285-200.png)"
                        ></div>

                        <div class="msg-bubble">
                            <div class="msg-info">
                                <div class="msg-info-name">ChatTutor</div>
                            </div>

                            <div class="msg-text">
                                Welcome to ChatTutor, feel free to ask any questions about this lesson.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clear-btn-container" id="clearContId">
                    <!-- Name must be change but DO NOT DELETE ( the messages get added before this container ) -->
                </div>
                <div style="background-color: black;" id="scrollHelper">
                    <!-- Helper for keeping scrolling  -->
                </div>
                <div class="loading-message" style="display: none;">
                    <img src="https://media.tenor.com/_62bXB8gnzoAAAAi/loading.gif" width="20" height="20"/>
                </div>
            </main>
            <form class="msger-inputarea">
              <input type="text" class="msger-input" placeholder="Enter your message..." id="msgInput">
              <div contenteditable="true" id="msgInputDiv" class="msger-input-div"> </div>
                <button type="submit" class="msger-send-btn" id="sendBtn">

                  <span style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                    💬
                  </span>
              </button>
                <button class="clear-btn" id="clearBtnId">
                    <span style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                        ⌫
                    </span>
                </button>

                <button class="stop-gen-btn" id="stopBtnId">
                    <span class="material-symbols-outlined" style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                        ⏹︎
                    </span>
                </button>
            </form>
          </section>

          <div id="body-overlay"></div>
         <!-- <nav class="real-menu" role="navigation">
                <section>
                    <div class="conainer col">
                        <h1>Settings</h1>
                        <a href="/">Main page</a>

                    </div>
                </section>
                <section>
                    <div class="container col">
                        <p>
                            Use the form below to upload files you want the model to learn
                            from. Upload multiple files as zip archives or pdfs/txts, or simply drag and drop them
                            all at once.
                        </p>
                        <p>
                            Each tuple of files you upload will be saved temporarily as a collection
                            and removed from our database when you reload your page.
                        </p>
                        <p>
                            If you upload multiple collections, you can use the select below
                            to select the selection you want the model to learn from for it to
                            be able to respond to you.
                        </p>
                    </div>
                </section>
               <!--<section style="display:none;">    
                    <div class="container overlay col ">
                      <h1>Upload Files</h1>
                      <div class="pswd-inputarea col">
                          <form id="uploadFileForm" class="no-enter" enctype="multipart/form-data">
                                <div class="input-group">
                                    <label for="files">Select file/files</label>
                                    <div class="area">
                                        <span>Upload File</span>
                                        <input type="file" class="multiple-upload" id="upload" name="file" multiple/>
                                    </div>
                                    <label for="name">Set a name</label>
                                    <input type="text" style="width: 100% !important" id="name" name="name" class="pswd-input">
                                </div>
                          </form>
                          <div class="row">
                            <button class="send nice-btn theme-button" id="sendformupload">
                              <span class="nice-btn material-symbols-outlined" style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                                  upload
                              </span>
                            </button>

                            <button class="send nice-btn theme-button" id="clearformupload">
                              <span class="nice-btn material-symbols-outlined" style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                                  close
                              </span>
                            </button>

                          </div>
                      </div>

                </section>   -->     
                <section style="display:none;">
                    <div class="container col">
                        <h3>Select collection</h3>
                        <select id="selectUploadedCollection">
                        </select>
                    </div>
                </section> 

                <section style="display: none;">
                    <div class="container col">
                        <h3>Select Model</h3>
                        <select id="modelDropdown">
                            <option value="gpt-3.5-turbo">GPT-3.5 (4k)</option>
                            <option value="gpt-3.5-turbo-16k">GPT-3.5 (16k)</option>
                            <option selected value="gpt-4">GPT-4 (8k)</option>
                            <option value="gpt-4-32k">GPT-4 (32k)</option>
                        </select>
                    </div>
                </section>

              </div>

              <div class="container" id = "uploadedFilesInfo">

              </div>
          </nav>

    
         <!-- <div id="nice-alert">
            <div class="type"></div>
            <span></span>
            <button class="nice-btn theme-button close">
              <span class="nice-btn material-symbols-outlined" style="font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle">
                  close
              </span>
            </button>
          </div> -->
          <button class="button-30" role="button" id="chattutor-toggler">ChatTutor</button>
    </div>

</div>

`

// Themes
    const lightMode = {
        body_bg: "white", //'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
        msger_bg: '#fff',
        border: '1px solid #ddd',
        left_msg_bg: '#FCFCFD',
        left_msg_txt: 'black',
        right_msg_bg: 'rgb(140, 0, 255)',
        msg_header_bg: '#FCFCFD',
        msg_header_txt: '#666',
        clear_btn_txt: '#999',
        msg_chat_bg_scrollbar: '#ddd',
        msg_chat_bg_thumb: '#bdbdbd',
        msg_chat_bg: '#fcfcfe',
        msg_input_bg: '#ddd',
        msg_input_area_bg: '#eee',
        msg_invert_image: 'invert(0%)',
        msg_input_color: "black",
        right_msg_txt: 'white',
        // legacy, not used
        imessageInterface_: {
            display_images: 'block',
            border_radius_all: '15px',
            msg_bubble_max_width: '450px',
            msg_bubble_width: 'unset',
            msg_margin: '5px',
            msg_chat_padding: '10px',
            right_msg_txt: 'white',
            msg_padding: '0',
            right_msg_bg_bgd: 'transparent',
        },
        // this is the interface
        normalInterface_: {
            display_images: 'none',
            border_radius_all: '4px',
            msg_bubble_max_width: 'unset',
            msg_bubble_width: '100%',
            msg_margin: '0',
            msg_chat_padding: '0',
            msg_chat_bg: '#f1f1f1',
            right_msg_bg: 'white',
            right_msg_txt: 'black',
            left_msg_bg: 'transparent',
            msg_padding: '5px 20px',
            right_msg_bg_bgd: 'white',
        }

    }

    function JSONparse(exp, or = '') {
        try {
            let a = JSON.parse(exp)
            return a;
        } catch (e) {
            return or;
        }
    }

    const darkMode = {
        body_bg: '#3e3c46',
        msger_bg: '#2d2d2d',
        border: '1px solid #2d2d2d',

        left_msg_txt: 'white',
        right_msg_bg: 'rgb(140, 0, 255)',
        msg_header_bg: 'rgba(41,41,41,0.75)',
        msg_header_txt: '#d5d5d5',
        clear_btn_txt: '#e5e5e5',
        msg_chat_bg_scrollbar: 'transparent',
        msg_chat_bg_thumb: '#656172',
        msg_input_bg: '#2f2f2f',
        msg_input_area_bg: '#252525',
        msg_invert_image: 'invert(100%)',
        msg_input_color: "white",
        right_msg_txt: 'white',
        msg_chat_bg: '#3e3c46',
        // legacy, not used
        imessageInterface_: {
            display_images: 'block',
            border_radius_all: '15px',
            msg_bubble_max_width: '450px',
            msg_bubble_width: 'unset',
            msg_margin: '5px',
            msg_chat_padding: '10px',
            right_msg_txt: 'white',
            right_msg_bg: 'rgb(140, 0, 255)',
            msg_header_bg: 'rgba(48,48,59,0.75)',
            msg_input_area_bg: '#3e3c46',
            msg_input_bg: '#2e2e33',
            left_msg_bg: '#302f36',
            msg_padding: '0',
            right_msg_bg_bgd: 'transparent',
        },
        // this is the interface
        normalInterface_: {
            msg_chat_bg_scrollbar: '#52505b',
            display_images: 'none',
            border_radius_all: '4px',
            msg_bubble_max_width: 'unset',
            msg_bubble_width: '100%',
            msg_margin: '0',
            msg_chat_padding: '0',
            right_msg_bg: '#302f36',
            right_msg_txt: 'white',
            msg_header_bg: 'rgba(48,48,59,0.75)',
            msg_input_area_bg: '#3e3c46',
            left_msg_bg: 'transparent',
            msg_input_bg: '#2e2e33',
            msg_padding: '5px 20px',
            right_msg_bg_bgd: '#302f36',
        }
    }

    function setProperties() {
        const theme = localStorage.getItem('theme')
        const interfaceTheme = 'normal'
        const object = theme === 'dark' ? darkMode : lightMode
        const interfaceObject = interfaceTheme === 'normal' ? object.normalInterface_ : object.imessageInterface_
        setPropertiesHelper(object)
        setPropertiesHelper(interfaceObject)
    }

    function setPropertiesHelper(themeObject) {

        for (let key in themeObject) {
            if (key.endsWith('_')) {

            } else {
                const property_replaced = key.replace(/_/g, '-')
                const property_name = `--${property_replaced}`
                const value = themeObject[key]

                document.documentElement.style.setProperty(property_name, value)
            }
        }
    }

    document.querySelectorAll(".no-enter").forEach(el => {
        el.addEventListener("keypress", function (event) {
            if (event.which == '13') {
                event.preventDefault();
            }
        })
    })


    var nicealert = document.getElementById("nice-alert")


    function alert(message, success = 0) {
        nicealert.querySelector("span").innerHTML = message
        let classes = ["fail", "default", "success"]
        classes.forEach(el => {
            nicealert.querySelector(".type").classList.remove(classes)
        })
        nicealert.querySelector(".type").classList.add = classes[success + 1]
        nicealert.classList.add("show")
        document.querySelector("#body-overlay").classList.add("show")

        nicealert.querySelector(".close").addEventListener("click", (e) => {
            nicealert.classList.remove("show")
            document.querySelector("#body-overlay").classList.remove("show")

        })

    }


    const upload_files = document.querySelectorAll('.multiple-upload');

    function onFile() {
        console.log(upload.files)
        var me = this,
            file = upload.files[0],
            name = file.name;

        upload.parentNode.querySelector("span").innerHTML = ""
        Array.from(upload.files).forEach(f => {
            var nm = f.name
            if (nm.length > 20) {
                nm = nm.substr(0, 16) + "..."
            }

            upload.parentNode.querySelector("span").innerHTML += nm + ", "
        })
    }

    upload_files.forEach(upload => {
        upload.addEventListener('dragenter', function (e) {
            upload.parentNode.className = 'area dragging';
        }, false);

        upload.addEventListener('dragleave', function (e) {
            upload.parentNode.className = 'area';
        }, false);

        upload.addEventListener('dragdrop', function (e) {
            onFile();
        }, false);

        upload.addEventListener('change', function (e) {
            onFile();
        }, false);
    })

    function clearFileInput(ctrl) {
        try {
            ctrl.value = null;
        } catch (ex) {
        }
        if (ctrl.value) {
            ctrl.parentNode.replaceChild(ctrl.cloneNode(true), ctrl);
        }

        try {
            ctrl.parentNode.querySelector("span").innerHTML = `<span>Upload File</span>`
        } catch (ex) {
        }
    }

    {
        /* <div class="area">
            <input type="file" class="multiple-upload" />
        </div> */
    }


//  function JSONparse(exp, or='') {
//     try {
//         var a = JSON.parse(exp)
//         return a;
//     } catch (e) {
//         return or;
//     }
// }


// Constants for embed mode and UI elements

// import {lightMode, darkMode, setProperties} from "./constants.js";
// import {alert} from "./nicealert.js"
// import { clearFileInput } from "./fileupload.js";
// import { JSONparse } from "./jsonparse.js";
// import { chattutor_embed } from "./chattutor.html.js";
// import { setFromDoc, clearFromDoc } from "./from_doc_ext.js";
    const embed_mode = true;

    let headers = new Headers();

    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:5000');
    headers.append('Access-Control-Allow-Credentials', 'true');
    headers.append('GET', 'POST', 'OPTIONS');


// Constants for bot and person details
    const BOT_IMG = "https://static.thenounproject.com/png/2216285-200.png";
    const PERSON_IMG = "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2c/Default_pfp.svg/1024px-Default_pfp.svg.png";
    const BOT_NAME = "ChatTutor";
    const PERSON_NAME = "Student";

    const LOCAL_STORAGE_CONVO = EMBEDDING_COLLECTION_NAME + "-conversation"


// URLs for production and debugging
    const prodAskURL = new URL("https:/chattutor.org/ask");
    const debugAskURL = new URL("http://localhost:5000/ask");

// Variables to hold conversation and message details
    var conversation = [];
    var original_file = "";
    let lastMessageId = null;
    var stopGeneration = false
    let selectedModel = "gpt-3.5-turbo" //document.getElementById('modelDropdown').value

// Configures UI
    if (embed_mode) {
        //   setupEmbedMode();
        setupEmbedMode_URL();

    }
    await new Promise(resolve => setTimeout(resolve, 100));

    setTheme('normal')

    const clear = document.getElementById('clearBtnId');
    const clearContainer = get('.clear-btn-container');
    const mainArea = get('.msger');
    const msgerForm = get(".msger-inputarea");
    const msgerInput = get(".msger-input");
    const msgerChat = get(".msger-chat");
// Get the send button
    const sendBtn = document.getElementById('sendBtn');
    const messageInput = document.getElementById('msgInput')
    const scrollHelper = document.getElementById('scrollHelper')
    const stopGenButton = document.getElementById('stopBtnId')
    const uploadZipButton = document.getElementById('uploadBtnId')
    const sendUploadedZipButton = document.getElementById('sendformupload')
    const uploadZipPapersForm = document.getElementById('uploadFileForm')
    const selectUploadedCollection = document.getElementById('selectUploadedCollection')
    const clearformupload = document.getElementById("clearformupload")
    const modelDropdown = document.getElementById('modelDropdown')
    const messageDIVInput = document.getElementById('msgInputDiv')
    const embedToggler = document.getElementById("chattutor-toggler")

    let uploadedCollections = []
    messageInput.addEventListener('input', (event) => {
        console.log(messageInput.value.length)
        sendBtn.disabled = messageInput.value.length === 0;
        clear.disabled = !(messageInput.value.length === 0);
    })


    stopGenButton.style.display = 'none'
// Listen for windoe resize to move the 'theme toggle button
    window.addEventListener('resize', windowIsResizing)

    function windowIsResizing() {
        console.log("resize")
        // the button for choosing themes snaps in place when the window is too small
        if (window.innerWidth < 1200) {
            //   themeBtnDiv.style.position = 'inherit'
            //   themeBtnDiv.style.top = '25px'
            //   themeBtnDiv.style.left = '25px'

            const arr = document.querySelectorAll('.theme-button')
            console.log(arr)
            arr.forEach(btn => {
                // btn.style.backgroundColor = 'transparent'
                // btn.style.color = 'var(--msg-header-txt)'
                // btn.style.textDecoration = 'underline'
                // btn.style.padding = '0'
                // btn.style.boxShadow = 'none'
                // btn.style.border = 'none'
                // btn.style.borderRadius = '0px'
                // btn.style.margin = '0'

                // btn.style.height = 'unset'
                // btn.style.width = 'unset'
            })

        } else {
            //   themeBtnDiv.style.position = 'fixed'
            //   themeBtnDiv.style.top = '25px'
            //   themeBtnDiv.style.left = '25px'
            const arr = document.querySelectorAll('.theme-button')
            console.log(arr)
            arr.forEach(btn => {
                btn.style.backgroundColor = 'rgb(140, 0, 255)'
                btn.style.color = 'white'
                btn.style.textDecoration = 'none'
                btn.style.padding = '10px'
                btn.style.boxShadow = '0 5px 5px -5px rgba(0, 0, 0, 0.2)'
                btn.style.border = 'var(--border)'
                btn.style.borderRadius = '50%'
                btn.style.margin = '0'
                btn.style.height = '40px'
                btn.style.width = '40px'
            })
        }
    }

    function getFormattedIntegerFromDate() {
        let d = Date.now()

    }

    const smallCard = {
        card_max_width: '867px'
    }

    const bigCard = {
        card_max_width: 'unset'
    }

    let theme = null
    let interfaceTheme = null


    function uploadMessageToDB(msg, chat_k) {
        if (msg.content === "") {
            return
        }
        let msg_id = uuidv4()
        console.log("Generated uuid " + msg_id)
        if (localStorage.getItem('user_id') === undefined || localStorage.getItem('user_id') === null) {
            console.log('not adding to db')
            return
        }
        const data_ = {
            message_id: msg_id,
            content: msg.content,
            role: msg.role,
            chat_k: chat_k,
            time_created: `${Date.now()}`,
            clear_number: getClearNumber(),
            course: EMBEDDING_COLLECTION_NAME,
            user_id: localStorage.getItem('user_id')
        }
        console.log(`DATA: ${JSON.stringify(data_)} `)
        if (ADD_MESSAGES_TO_DB) {
            fetch(BASE_URL + '/addtodb', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data_)
            })
                .then((response) => {
                    console.log("andu")
                    return response.json()
                }).then(data => {
                console.log(data)
            }).catch(e => {
                console.log("error")
            });
        }
        return msg_id
    }

// Event listener to clear conversation
    clear.addEventListener('click', clearConversation);

// Event listener to handle form submission
    msgerForm.addEventListener("submit", handleFormSubmit);

// Event listener to load conversation from local storage on DOM load
    document.addEventListener("DOMContentLoaded", loadConversationFromLocalStorage);
// REMVE ALL from collections saved in local storage + clean up local storage
    document.addEventListener("DOMContentLoaded", clearCollectionsFromLocalStorage)

    document.addEventListener('DOMContentLoaded', setThemeOnRefresh)

    document.addEventListener('DOMContentLoaded', windowIsResizing)

// Event listener for toggling the theme
    themeBtn.addEventListener('click', toggleDarkMode)

    stopGenButton.addEventListener('click', stopGenerating)

    modelDropdown.addEventListener('change', handleModelDropdownChange);

    function handleModelDropdownChange(event) {
        selectedModel = event.target.value;
        console.log("Selected model:", selectedModel);
    }


// I dodn't know if i should install uuidv4 using npm or what should i use
    function uuidv4() {
        return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, c =>
            (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        );
    }

    function setChatId() {
        localStorage.setItem('conversation_id', uuidv4())
    }

    function getChatId() {
        return localStorage.getItem('conversation_id')
    }

    function increaseClearNumber() {
        let clnr = getClearNumber()
        let clear_number = parseInt(clnr)
        localStorage.setItem('clear_number', `${clear_number + 1}`)
    }

    function resetClearNumber() {
        localStorage.setItem('clear_number', '0')
    }

    if (localStorage.getItem('clear_number') == null) {
        localStorage.setItem('clear_number', '0')
    }

    if (localStorage.getItem('conversation_id') == null) {
        localStorage.setItem('conversation_id', `${uuidv4()}`)
    }

    function getClearNumber() {
        return localStorage.getItem('clear_number')
    }

    function reinstantiateChatId() {
        increaseClearNumber()
    }

// function for keeping the theme whn the page refreshes
    function setThemeOnRefresh() {
        // disable send button
        sendBtn.disabled = messageInput.value.length === 0;
        if (getChatId() == null) {
            setChatId()
        }

        if (getClearNumber() == null) {
            resetClearNumber()
        }

        theme = localStorage.getItem('theme')
        if (theme == null) {
            setTheme('dark')
        } else {
            setTheme(theme)
        }

        interfaceTheme = 'normal'
        setTheme('normal')

    }

// helper function
    function setTheme(th) {
        setProperties()
        const _style = "\"font-size: 15px !important; padding: 0 !important; margin: 0 !important; vertical-align: middle\""
        // themeBtn.innerHTML = theme === "dark" ? `<span class="material-symbols-outlined" style=${_style}> light_mode </span>` :
        //     `<i class="material-symbols-outlined" style=${_style}> dark_mode\n </i>`
    }

// function that toggles theme
    function toggleDarkMode() {
        if (theme === 'light') {
            theme = 'dark'
        } else if (theme === 'dark') {
            theme = 'light'
        } else {
            theme = 'dark'
        }
        localStorage.setItem('theme', theme)
        setTheme(theme)
    }

    function toggleInterfaceMode() {
        interfaceTheme = 'normal'
        localStorage.setItem('interfacetheme', interfaceTheme)
        setTheme(interfaceTheme)

    }

    function clearConversation() {
        conversation = [];
        localStorage.setItem(LOCAL_STORAGE_CONVO, JSON.stringify([]));
        reinstantiateChatId()
        var childNodes = msgerChat.childNodes;
        for (var i = childNodes.length - 3; i >= 2; i--) {
            var childNode = childNodes[i];
            if (childNode.id !== 'clearContId' && childNode.id !== 'clearBtnId') {
                childNode.parentNode.removeChild(childNode);
            }
        }
    }

    function stopGenerating() {
        stopGeneration = true
        sendBtn.disabled = messageInput.value.length == 0;
        clear.disabled = !(messageInput.value.length == 0);
    }


    function loadConversationFromLocalStorage() {
        let conversation = JSON.parse(localStorage.getItem(LOCAL_STORAGE_CONVO))
        if (conversation) {
            conversation.forEach(message => {
                lastMessageId = null
                addMessage(message["role"],
                    message["content"], false,
                    message["message_id"],
                    message["context_documents"])
                if (message["context_documents"]) {
                    //setLatMessageHeader(message["context_documents"])
                }
            })
        } else conversation = []
        //.typesetPromise();
    }

    function loadCollectionsFromLocalStorage() {
        const collections = JSON.parse(localStorage.getItem("uploaded-collections")) //TODO
        if (collections) {
            collections.forEach(collname => {
                addCollectionToFrontEnd(collname)
            })
        }
    }

    function clearCollectionsFromLocalStorage() {
        let collections = JSON.parse(localStorage.getItem("uploaded-collections"))
        if (collections) {
            collections.forEach(collname => {
                fetchClearCollection(collname)
            })
        }
    }

    function fetchClearCollection(collname) {
        console.log("clearing ", collname)
        let args = {
            "collection": collname
        }
        fetch("/delete_uploaded_data", {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(args)
        }).then(response => response.json()).then(data => {
            console.log("deleted " + data["deleted"])
        })
    }


    function queryGPT(fromuploaded = false, uploaded_collection_name = EMBEDDING_COLLECTION_NAME) {
        let collection_name = EMBEDDING_COLLECTION_NAME
        let selected_collection_name = EMBEDDING_COLLECTION_NAME
        // if (selectUploadedCollection && !selectUploadedCollection.options[ selectUploadedCollection.selectedIndex ]) {
        //   alert("Please upload some files for the tutor to learn from! Click on menu!")
        //   return
        // }
        if (selectUploadedCollection.options.length > 0) {
            selected_collection_name = selectUploadedCollection.options[selectUploadedCollection.selectedIndex].value
        }
        const args = {
            "conversation": conversation,
            "collection": EMBEDDING_COLLECTION_NAME,
            "key": localStorage.getItem('key'),
            "user_id": localStorage.getItem('user_id'),
            "chattutor_version": 'new'
        }
        if (embed_mode) {
            console.log(original_file)
            args.from_doc = original_file
        }
        //if (READ_FROM_DOC != null) args.from_doc = READ_FROM_DOC

        args.selectedModel = selectedModel
        console.log("POSTING ", args, "to ", BASE_URL + '/ask')
        document.querySelector(".loading-message").style = "display: flex;"
        fetch(BASE_URL + '/ask', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(args)
        }).then(async response => {
            if(response.headers.get('content-type') === 'application/json') {
                if ((await response.json())['message'] === 'notloggedin') {
                    console.log('user not logged in!')
                    let qs_id = document.getElementById("loginError");
                    console.log(qs_id)
                    qs_id.style.display = "block"
                    qs_id.style.opacity = "100"
                    return
                }
            }
            const reader = response.body.getReader();
            let accumulatedContent = "";
            let isFirstMessage = true;
            let context_documents = null;

            function read() {
                console.log("validating")
                validate_and_set()
                reader.read().then(({
                                        done,
                                        value
                                    }) => {
                    if (done) {
                        // Enable the send button when streaming is done
                        sendBtn.disabled = messageInput.value.length === 0;
                        clear.style.display = 'block'
                        stopGenButton.style.display = 'none'
                        stopGeneration = false
                        // uploadMessageToDB({
                        //     content: accumulatedContent,
                        //     role: 'assistant'
                        // }, getChatId())
                        return;
                    }
                    const strValue = new TextDecoder().decode(value);
                    const messages = strValue.split('\n\n').filter(Boolean).map(chunk => JSONparse(chunk.split('data: ')[1]));
                    let message;
                    for (var messageIndex in messages) {
                        message = messages[messageIndex]
                        if (stopGeneration === false) {
                            if (message.message.valid_docs) {
                                context_documents = message.message.valid_docs
                                console.log(context_documents)
                            }
                            const contentToAppend = message.message.content ? message.message.content : "";
                            accumulatedContent += contentToAppend;
                        }
                        if (isFirstMessage) {
                            console.log("added", accumulatedContent)
                            addMessage("assistant", accumulatedContent, false, "no_id");
                            setLatMessageHeader(context_documents)
                            isFirstMessage = false;
                        } else {
                            let id_1 = ""
                            if (typeof (message.message.content) == 'undefined') {
                                id_1 = uploadMessageToDB(
                                    {
                                        content: accumulatedContent,
                                        role: "assistant"
                                    },
                                    getChatId()
                                );

                                conversation.push({
                                    "message_id": id_1,
                                    "role": 'assistant',
                                    "content": accumulatedContent,
                                    "context_documents": context_documents
                                })
                                localStorage.setItem(LOCAL_STORAGE_CONVO, JSON.stringify(conversation))
                            }
                            console.log("updated", accumulatedContent)

                            scrollHelper.scrollIntoView()
                            updateLastMessage(accumulatedContent, id_1);

                            if (message.message.error) {
                                conversation.push({
                                    "role": 'assistant',
                                    "content": accumulatedContent
                                })
                                localStorage.setItem(LOCAL_STORAGE_CONVO, JSON.stringify(conversation))
                            }
                        }
                        if (stopGeneration === true) {
                            const id_2 = uploadMessageToDB({
                                content: accumulatedContent,
                                role: 'assistant'
                            }, getChatId())
                            accumulatedContent += " ...Stopped generating";
                            conversation.push({
                                "role": 'assistant',
                                "content": accumulatedContent,
                                "context_documents": context_documents,
                                "message_id": id_2
                            })
                            localStorage.setItem(LOCAL_STORAGE_CONVO, JSON.stringify(conversation))

                            sendBtn.disabled = messageInput.value.length == 0;
                            clear.disabled = !(messageInput.value.length == 0);
                            clear.style.display = 'block'
                            stopGenButton.style.display = 'none'

                            scrollHelper.scrollIntoView()
                            updateLastMessage(accumulatedContent);

                            break
                        }
                    }
                    if (stopGeneration === false) {
                        read();
                    } else {
                        stopGeneration = false

                    }
                    document.querySelector(".loading-message").style = "display: none;"
                }).catch(err => {
                    console.error('Stream error:', err);
                    sendBtn.disabled = false;
                    clear.style.display = 'block'
                    stopGenButton.style.display = 'none'
                    stopGeneration = false
                    document.querySelector(".loading-message").style = "display: none;"

                });
                //.typesetPromise();
            }

            read();
            // //.typesetPromise();
            document.querySelector(".loading-message").style = "display: none;"

        }).catch(err => {
            console.error('Fetch error:', err);
            // Enable the send button in case of an error
            sendBtn.disabled = false;
            clear.style.display = 'block'
            stopGenButton.style.display = 'none'
            stopGeneration = false
            document.querySelector(".loading-message").style = "display: none;"
            // just make this go away.
            console.log("err")
            let qs = document.querySelector(".scp-error");
            let qs_id = document.getElementById("scpError");
            qs_id.style.display = "block"

            function delay(time) {
                return new Promise(resolve => setTimeout(resolve, time));
            }

            delay(500).then(() => {
                qs.classList.add("scp-error-show")
            })


        });
    }

    function formatMessage(message, makeLists = true) {
        const messageArr = message.split("\n")

        let messageStr = ""
        let listSwitch = 0
        for (let messageArrIndex in messageArr) {
            const paragraph = messageArr[messageArrIndex]
            if (paragraph.startsWith('- ') && makeLists) {
                if (listSwitch === 0) {
                    messageStr += "<ul style=\"padding-left: 15px !important;\">"
                }

                messageStr += `<li><p>${paragraph.slice(2)}</p></li>`

                listSwitch = 1

            } else if (listSwitch === 1) {
                messageStr += "</ul>"
                messageStr += `<p>${paragraph}</p>`
                listSwitch = 0
            } else {
                messageStr += `<p>${paragraph}</p>`
                listSwitch = 0
            }

        }
        return messageStr
    }


    function setLatMessageHeader(context_documents, lastMessageIdParam, add = true) {

        if (context_documents == false)
            return ''
        if (!lastMessageIdParam) {
            lastMessageIdParam = lastMessageId
        }
        if (add == false) {
            var docs = ''
            context_documents.forEach(doc => {
                // TO not break HTML
                doc.metadata["summary"] = 0

                var data = `${JSON.stringify(doc.metadata).replace("&quot;", '"')}`
                docs += `<div class="msg-context-doc col ${lastMessageIdParam}-context" data-doc="${doc.metadata.doc}">
          <div style="align-self: self-start;">
            <span>${doc.metadata.doc}</span>
          </div>

          <div class="info col">
            <div>
              <div class="askmore context-info col" onclick='setFromDoc(${data})'>Ask about</div>
              <div class="inform context-info col" onclick='setDocInfo(${data})'>Info</div>
            </div>
          </div>
        </div>`
            })
            return docs;
        }


        if (lastMessageIdParam) {
            const lastMessageElement = document.querySelector(`#${lastMessageIdParam} .msg-text`);
            if (lastMessageElement) {
                var docs = ''
                context_documents.forEach(doc => {
                    docs += `<div class="msg-context-doc col ${lastMessageIdParam}-context" data-doc="${doc.metadata.doc}">
          <div style="align-self: self-start;">
            <span>${doc.metadata.doc}</span>
          </div>

          <div class="info col">
            <div>
              <div class="askmore context-info col" onclick='setFromDoc(${JSON.stringify(doc.metadata)})'>Ask about</div>
              <div class="inform context-info col" onclick='setDocInfo(${JSON.stringify(doc.metadata)})'>Info</div>
            </div>
          </div>
        </div>`
                })
                if (add)
                    document.querySelector(`#${lastMessageIdParam}`).innerHTML = `
        <div class="msg-header-context">${docs}</div>
        ${document.querySelector(`#${lastMessageIdParam}`).innerHTML}
      `;

                return docs
            } else {
                console.error('Cannot find the .msg-text element to update.');
            }
        } else {
            console.error('No message has been added yet.');
        }

        return ''
    }

    function updateLastMessage(newContent, msg_db_id) {
        if (lastMessageId) {
            const lastMessageElement = document.querySelector(`#${lastMessageId} .msg-text`);
            if (lastMessageElement) {
                const newContentFormatted = formatMessage(newContent)
                document.querySelector(`#${lastMessageId} .msg-text`).innerHTML = newContentFormatted;
                document.querySelector(`#${lastMessageId} .msg-id`).innerHTML = msg_db_id;
            } else {
                console.error('Cannot find the .msg-text element to update.');
            }
        } else {
            console.error('No message has been added yet.');
        }
        // //.typesetPromise();

    }

    if (clearformupload)
        clearformupload.addEventListener("click", () => {
            clearFileInput(document.querySelector("#upload"))
        })


    function addMessage(role, message, updateConversation, msg_db_id, lastmessageheader = false) {
        let role_name
        let img
        let side

        if (role === "assistant") {
            role_name = BOT_NAME;
            img = BOT_IMG;
            side = "left";

        } else {
            role_name = PERSON_NAME;
            img = PERSON_IMG;
            side = "right";
        }

        const messageId = 'msg-' + new Date().getTime();
        lastMessageId = messageId;

        // if you want to make the robot white ( of course it doesn't work well in safari ), so -- not in use right now
        var invertImage = 'invert(0%)'
        if (side === "left") {
            invertImage = 'var(--msg-invert-image)'
        }

        const messageStr = formatMessage(message, role === "assistant")

        const feedback_display = (role === 'assistant') ? 'flex' : 'none !important'

        const msgHTML = `
    <div class="msg ${side}-msg" id="${messageId}">
    <div class="msg-header-context">${setLatMessageHeader(lastmessageheader, messageId, false)}</div>

    <div class="msg-bgd">
      <div class="msg-img" style="background-image: url(${img})"></div>

      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">${role_name}</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>

        <div class="msg-text">${messageStr}</div>
        <div class="feedback row" style="display: ${feedback_display};">
          <div class="msg-info-name msg-id" style="display: none !important;">${msg_db_id}</div>
          <div class="fit feedback-btn feedback-positive" onclick='
                ((e) => {
                  const testmode = false
                  const BASE_URL = testmode ? "http://localhost:5000" : "https://beta-chattutor-nbqjgewnea-uc.a.run.app"
                  e = e || window.event;
                  var targ = e.target || e.srcElement || e;
                  if (targ.nodeType === 3) targ = targ.parentNode; // defeat Safari bug
                  var id_elem = targ.parentElement.parentElement.children[0];
                  console.log(targ.parentElement.parentElement.children[0]);
                  var target_msg_id = id_elem.innerText;
                
                  const payload = {
                    message_id : target_msg_id,
                    content : "positive"
                  }
                
                  console.log("feedback payload")
                  console.log(payload)
                  console.log(BASE_URL)
                  fetch(BASE_URL + "/addmessagefeedback", {
                    method: "POST",
                    body: JSON.stringify(payload),
                    headers: { "Content-Type": "application/json" },
                  })
                    .then((response) => response.json())
                    .then((data) => {
                      console.log("Added payload: ")
                      console.log(data)
                    })
              })(event)
          '>
            <i class="large material-icons">👍🏻</i>
          </div>
          
          <div class="fit feedback-btn feedback-negative" onclick='
                ((e) => {
                  const testmode = false
                  const BASE_URL = testmode ? "http://localhost:5000" : "https://beta-chattutor-nbqjgewnea-uc.a.run.app"
                  e = e || window.event;
                  var targ = e.target || e.srcElement || e;
                  if (targ.nodeType === 3) targ = targ.parentNode; // defeat Safari bug
                  var id_elem = targ.parentElement.parentElement.children[0];
                  console.log(targ.parentElement.parentElement.children[0]);
                  var target_msg_id = id_elem.innerText;
                
                  const payload = {
                    message_id : target_msg_id,
                    content : "negative"
                  }
                
                  console.log("feedback payload")
                  console.log(payload)
                  console.log(BASE_URL)
                  fetch(BASE_URL + "/addmessagefeedback", {
                    method: "POST",
                    body: JSON.stringify(payload),
                    headers: { "Content-Type": "application/json" },
                  })
                    .then((response) => response.json())
                    .then((data) => {
                      console.log("Added payload: ")
                      console.log(data)
                    })
              })(event)
          '>
            <i class="large material-icons">👎🏻</i>
          </div>
        </div>
      </div>
      </div>
    </div>
  `;

        clearContainer.insertAdjacentHTML("beforebegin", msgHTML);

        // Find the newly added message and animate it
        const newMessage = document.getElementById(messageId);
        newMessage.style.opacity = "0";
        newMessage.style.transform = "translateY(1rem)";

        // //.typesetPromise([newMessage]);

        // Trigger reflow to make the transition work
        void newMessage.offsetWidth;

        // Start the animation
        newMessage.style.opacity = "1";
        newMessage.style.transform = "translateY(0)";
        msgerChat.scrollTop += 500;
        if (updateConversation) {
            conversation.push({"role": role, "content": message})
            localStorage.setItem(LOCAL_STORAGE_CONVO, JSON.stringify(conversation))
        }

    }


    function setupEmbedMode() {
        // Setup minimize and expand buttons to toggle 'minimized' class on mainArea
        const minimize = get('.msger-minimize');
        const expand = get('.msger-expand');
        minimize.addEventListener('click', () => mainArea.classList.toggle('minimized'));
        expand.addEventListener('click', () => mainArea.classList.toggle('minimized'));

        // Extract and store the name of the original file from the 'Download source file' link
        const download_original = document.querySelectorAll('[title="Download source file"]')[0];
        original_file = download_original.getAttribute("href").slice(download_original.getAttribute("href").lastIndexOf("/") + 1);
    }


// Utility functions
    function get(selector, root = document) {
        return root.querySelector(selector);
    }

    function formatDate(date) {
        const h = "0" + date.getHours();
        const m = "0" + date.getMinutes();

        return `${h.slice(-2)}:${m.slice(-2)}`;
    }


    function uploadFile() {
        let myFormData = new FormData(uploadZipPapersForm)
        const formDataObj = {};
        myFormData.forEach((value, key) => (formDataObj[key] = value));
        console.log(formDataObj)

        sendUploadedZipButton.querySelector("span").innerHTML = `<img src="./images/loading.gif" style="width: 40px; height: 40px;">`

        console.log(formDataObj["file"])
        if (formDataObj["file"]["name"] == '') {
            alert("Please upload a file!")
            sendUploadedZipButton.querySelector("span").innerHTML = "upload"

            return
        }

        fetch(BASE_URL + '/upload_data_to_process', {
            method: 'POST',
            body: new FormData(uploadZipPapersForm)
        }).then(response => response.json()).then(data => {
            let created_collection_name = data['collection_name']
            console.log("Created collection " + created_collection_name)
            if (created_collection_name == false || created_collection_name == "false") {
                alert("Select file")
            } else {
                addCollectionToFrontEnd(created_collection_name)

            }


            sendUploadedZipButton.querySelector("span").innerHTML = "upload"
            clearFileInput(document.querySelector("#upload"))
        })
    }

    function addCollectionToFrontEnd(created_collection_name) {
        uploadedCollections.push(created_collection_name)
        console.log(uploadedCollections)
        selectUploadedCollection.innerHTML += `
      <option value=${created_collection_name}>${created_collection_name.split("_")[0]}:collection</option>
    `
        localStorage.setItem("uploaded-collections", JSON.stringify(uploadedCollections))
        alert(`Created collection ${created_collection_name}`)
    }

    if (sendUploadedZipButton)
        sendUploadedZipButton.addEventListener("click", uploadFile)


    function hasClass(ele, cls) {
        return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
    }

    function addClass(ele, cls) {
        if (!hasClass(ele, cls)) ele.className += " " + cls;
    }

    function removeClass(ele, cls) {
        if (hasClass(ele, cls)) {
            var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
            ele.className = ele.className.replace(reg, ' ');
        }
    }

//Prevent the function to run before the document is loaded
    document.addEventListener('readystatechange', function () {
        if (document.readyState === "complete") {
            // init();
        }
    });


    if (!embed_mode)
        document.querySelector(".close-notif").addEventListener('click', e => {
            // clearFromDoc();
        })


    if (!embed_mode)
        document.querySelector(".close-arxiv").addEventListener('click', e => {
            // clearDocInfo();
        })

// -------- inchat

// const addUrlButton = document.getElementById('addUrl')
    let file_array_to_send = undefined
    let collectionName = undefined
    const msgerDiv = document.getElementById('msgInputDiv')

    function setNewCollection() {
        collectionName = `${uuidv4()}`.substring(0, 10)
    }

    setNewCollection()

    async function uploadSiteUrl() {


    }


    let the_file_arr = undefined

    msgerDiv.addEventListener('drop', e => {
        e.preventDefault()
        const transfer = e.dataTransfer
        const files = transfer.files
        if (the_file_arr === undefined) {
            the_file_arr = [...files]
        } else {
            the_file_arr = [...the_file_arr, ...files]
        }

        const the_files = [...files]
        for (const ind in the_files) {
            const file = the_files[ind]
            msgerDiv.innerHTML += ` :file: ${file.name} `
        }
        updateEditor()
    })

    function validateUrls() {
        let arr = []
        if (msgerInput.value.includes(':url:') || msgerInput.value.includes(':file:')) {

        } else {
            return undefined
        }
        console.log(msgerInput.value)
        var inputval = msgerInput.value
        console.log(inputval)

        let strs = inputval.split(' ')
        console.log(strs)
        let sw = 0
        var index = 0
        while (index < strs.length) {
            const _str = strs[index]

            if (_str === ":url:" && index + 1 < strs.length) {
                arr = [...arr, strs[index + 1]]
            } else if (_str.includes(":url:")) {
                var aux = _str.split(":url:")
                console.log(aux)
                arr = [...arr, aux[1].split('').splice(1).join('')]
            }
            index++;
            // if(sw == 1 && _str !== ':file:' && _str != ':url:' && _str.length > 3) {
            //     arr = [...arr, _str]
            // }
            // if (_str === ':url:') {
            //     sw = 1
            // } else if(_str === ':file:') {
            //     sw = 0
            // }
        }
        console.log("URL/FILES", arr)
        return arr;


    }

    function validateMsgInputAndDisable() {
        let str = validateUrls()

        if (str !== undefined) {
            addUrlButton.style.display = 'block'
            addUrlButton.innerText = 'Press enter to add'
            sendBtn.disabled = true


        } else {

            addUrlButton.style.display = 'none'
            sendBtn.disabled = false
        }
        sendBtn.disabled = messageInput.value.length === 0;
        clear.disabled = !(messageInput.value.length === 0);


    }

    function inputTextDidChange() {
        let inner = msgerInput.innerHTML
        validateMsgInputAndDisable()
        console.log('val:', msgerInput.value)
    }

    msgerInput.addEventListener('input', inputTextDidChange)


// EO New code


    function getTextSegments(element) {
        const textSegments = [];
        Array.from(element.childNodes).forEach((node) => {
            switch (node.nodeType) {
                case 3:
                    textSegments.push({text: node.nodeValue, node});
                    break;

                case 1:
                    textSegments.splice(textSegments.length, 0, ...(getTextSegments(node)));
                    break;

                default:
                    throw new Error(`Unexpected node type: ${node.nodeType} ${Node.TEXT_NODE}`);
            }
        });
        return textSegments;
    }

    function updateEditor() {
        const sel = document.getSelection();
        console.log(sel)
        try {

            const textSegments = getTextSegments(msgerDiv);
            const textContent = textSegments.map(({text}) => text).join('');
            console.log('dsdsd')
            let anchorIndex = null;
            let focusIndex = null;
            let currentIndex = 0;
            textSegments.forEach(({text, node}) => {
                if (node === sel.anchorNode) {
                    anchorIndex = currentIndex + sel.anchorOffset;
                }
                if (node === sel.focusNode) {
                    focusIndex = currentIndex + sel.focusOffset;
                }
                currentIndex += text.length;
            });

            msgerDiv.innerHTML = renderText(textContent);
            msgerInput.value = msgerDiv.innerText.replaceAll(' ', ' ')

            sendBtn.disabled = messageInput.value.length === 0;
            clear.disabled = !(messageInput.value.length === 0);
            restoreSelection(anchorIndex, focusIndex);

            validateMsgInputAndDisable()
            if (the_file_arr !== undefined) {
                file_array_to_send = the_file_arr.filter((elem) => {
                    return msgerInput.value.includes(elem.name)
                })
                console.log(file_array_to_send)
            }
        } catch (e) {
            console.log(e)
            return;
        }

    }

    function restoreSelection(absoluteAnchorIndex, absoluteFocusIndex) {
        const sel = document.getSelection();
        const textSegments = getTextSegments(msgerDiv);
        let anchorNode = msgerDiv;
        let anchorIndex = 0;
        let focusNode = msgerDiv;
        let focusIndex = 0;
        let currentIndex = 0;
        textSegments.forEach(({text, node}) => {
            const startIndexOfNode = currentIndex;
            const endIndexOfNode = startIndexOfNode + text.length;
            if (startIndexOfNode <= absoluteAnchorIndex && absoluteAnchorIndex <= endIndexOfNode) {
                anchorNode = node;
                anchorIndex = absoluteAnchorIndex - startIndexOfNode;
            }
            if (startIndexOfNode <= absoluteFocusIndex && absoluteFocusIndex <= endIndexOfNode) {
                focusNode = node;
                focusIndex = absoluteFocusIndex - startIndexOfNode;
            }
            currentIndex += text.length;
        });

        sel.setBaseAndExtent(anchorNode, anchorIndex, focusNode, focusIndex);
    }


    const highlights = [{word: ":url:", col: "#00eaff"}, {word: ":file:", col: "#b965ff"}]

    function renderText(text) {
        console.log('text!')
        var words = text.split(/(\s+)/);
        var arr = new Array()
        var lastf = undefined
        var el = undefined
        var windex = 0
        console.log('render text!')
        words.forEach(f => {
            if (f == ":url:" || f == ":file:" || windex == words.length - 1) {
                if (el !== undefined && lastf !== undefined)
                    arr.push(el)
                if (f != undefined)
                    arr.push(f)
            } else if (lastf == ":url:" || lastf == ":file:") {
                el = f
            } else {
                el = el + f
            }

            lastf = f
            windex++
        })
        for (var i = 0; i < arr.length; ++i) {
            arr[i] = arr[i].trim()
        }
        arr = arr.filter(a => a.length > 0)
        console.log("ARRRRRR, ", words, arr, messageInput.value)

        // @Andu, arr does not work :( help
        const output = words.map((word, ind, vec) => {
            for (const ihighlight in highlights) {
                const high = highlights[ihighlight]
                if (word === high.word) {
                    if (ihighlight == 0)
                        return `</span><span style=\"padding: 1px; margin: 0; margin-right: 5px; border-radius: 2px; background-color: ${high.col}; color: black\">${word}`

                    return `</span><span style=\"padding: 1px; margin: 0; margin-right: 5px; border-radius: 2px; background-color: ${high.col}; color: black\">${word}`
                }


                if (ind >= 2) {
                    if (words[ind - 2] === ":file:" && file_array_to_send !== undefined) {
                        console.log(words[ind - 1], file_array_to_send)
                        if (file_array_to_send.some((elem) => {
                            return elem.name === word
                        })) {
                            return `<span style=\"padding: 1px; margin: 0; border-radius: 2px; background-color: #a1e8a1; color: black\">${word}</span>`
                        }
                    }
                }
            }
            return word
        })
        return output.join('');
    }

    msgerDiv.addEventListener('input', updateEditor)

    updateEditor()

    msgerDiv.onkeydown = function (e) {
        if (e.key === "Enter") {
            e.preventDefault()
            handleFormSubmit_noEvent()
            validate_and_set()
            msgerDiv.innerText = ""
            msgerInput.value = ""

        }
    }

    async function handleFormSubmit(event) {
        event.preventDefault();
        await handleFormSubmit_noEvent();
    }

    const COLLECTION_NAME = undefined

    async function handleFileUpload() {
        addUrlButton.style.display = 'block'
        addUrlButton.innerText = 'Uploading files...'
        const body = file_array_to_send
        let form_data = new FormData()
        form_data.append('collection_name', collectionName)
        for (const ind in file_array_to_send) {
            form_data.append('file', file_array_to_send[ind])
        }
        const response = await fetch(BASE_URL + '/upload_data_from_drop', {
            method: 'POST',
            headers: {'Accept': 'multipart/form-data'},
            body: form_data
        })

        const coll = await response.json()

        addUrlButton.innerText = 'Done uploading files'
        return coll
    }

    async function handleFormSubmit_noEvent() {
        const msgText = msgerInput.value;
        if (msgText.startsWith(':url:') || msgText.startsWith(':file:')) {
            let url_array = undefined
            let fil_array = undefined
            if (msgText.includes(':url:')) {
                const s_json = await uploadSiteUrl()
                url_array = s_json['urls']
            }
            if (msgText.includes(':file:') && file_array_to_send !== undefined) {
                const f_json = await handleFileUpload()
                fil_array = f_json['files_uploaded_name']
            }


            if (url_array !== undefined) {
                for (const i in url_array) {
                    msgerDiv.innerHTML += `<span style="margin: 0; padding: 0">uploaded_urls: ${url_array[i]} </span>`
                }
            }


            if (fil_array !== undefined) {
                for (const i in fil_array) {
                    msgerDiv.innerHTML += `<span style="margin: 0; padding: 0">uploaded_files: ${fil_array[i]} </span>`
                }
            }


            addCollectionToFrontEnd(collectionName)
            return;
        }
        if (!msgText) return;
        // if (selectUploadedCollection && !selectUploadedCollection.options[ selectUploadedCollection.selectedIndex ]) {
        //   alert("Please upload some files for the tutor to learn from!")
        //   return
        // }

        // Disable the send button
        sendBtn.disabled = true;
        clear.style.display = 'none'
        stopGenButton.style.display = 'block'
        let us_msg_id = uploadMessageToDB({role: 'user', content: msgText}, getChatId());
        addMessage("user", msgText, true, us_msg_id);

        msgerInput.value = "";
        queryGPT();
    }

// EO new code

    if (!embed_mode) {
        embedToggler.style.display = "none";
    } else {
        let embedCHATTUTOR = document.querySelector(".embed")
        embedToggler.addEventListener("click", (e) => {
            embedCHATTUTOR.classList.add("embed-open");
        })

        document.querySelector(".close-embed").addEventListener("click", () => {
            embedCHATTUTOR.classList.remove("embed-open");
            document.querySelector('.scp-error').classList.remove(".scp-error-show")
            document.getElementById("scpError").style.display = 'none'
        })
    }
})